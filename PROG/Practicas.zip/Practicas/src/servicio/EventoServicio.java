package servicio;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import dominio.Categoria;
import dominio.Evento;
import dominio.Organizador;
import dominio.Usuario;
import persistencia.CategoriaDao;
import persistencia.EventoDao;

public class EventoServicio implements IEventoServicio {
	private final Scanner sc;
	private EventoDao eventoDao;
	private CategoriaDao categoriaDao;

	public EventoServicio(Scanner sc) {
		this.sc = sc;
		this.eventoDao = new EventoDao();
		this.categoriaDao = new CategoriaDao();
	}

	@Override
	public void mostrarEventos() {
		System.out.println("Estos son los eventos disponibles:");
		// Recorremos los valores del hashmap del DAO
		eventoDao.obtenerEventos().values().forEach(evento -> {
			System.out.println("- " + evento.getNombre() + " | Fecha: " + evento.getFecha() + " | Ubicación: " + evento.getUbicacion());
		});
	}

	@Override
	public void inscribirUsuario(Usuario usuario) {
		System.out.println("Escribe el nombre del evento al que te quieres apuntar:");
		String nombreEvento = sc.nextLine();
		
		Evento evento = eventoDao.obtenerEventos().get(nombreEvento);
		
		if (evento != null) {
			// Llamamos al método que ya tienes creado en tu clase Usuario
			usuario.inscribirEvento(evento);
		} else {
			System.out.println("El evento '" + nombreEvento + "' no existe.");
		}
	}

	@Override
	public void cancelarInscripcion(Usuario usuario) {
		System.out.println("Escribe el nombre del evento del que te quieres borrar:");
		String nombreEvento = sc.nextLine();
		
		Evento evento = eventoDao.obtenerEventos().get(nombreEvento);
		
		if (evento != null) {
			// Llamamos al método de tu clase Usuario
			usuario.cancelarInscripcion(evento);
		} else {
			System.out.println("Evento no encontrado.");
		}
	}

	@Override
	public void mostrarEventosUsuario(Usuario usuario) {
	    System.out.println("Los eventos en los que está inscrito " + usuario.getNombre() + "son:");
	    
	    // Obtenemos la colección de eventos y la recorremos con un for normal
	    for (Evento e : eventoDao.obtenerEventos().values()) {
	        // Comprobamos si el usuario está en la lista de asistentes de ese evento
	        if (e.getAsistentes().contains(usuario)) {
	            System.out.println("- " + e.getNombre());
	        }
	    }
	}

	@Override
	public void mostrarEventosOrganizador(Organizador organizador) {
	    System.out.println("Eventos organizados por: " + organizador.getNombre());
	    
	    // Recorremos todos los eventos del sistema
	    for (Evento e : eventoDao.obtenerEventos().values()) {
	        // Comparamos el nombre del organizador del evento con el que recibimos
	        if (e.getOrganizador().getNombre().equalsIgnoreCase(organizador.getNombre())) {
	            System.out.println("- " + e.getNombre());
	        }
	    }
	}

	@Override
	public void crearEvento(Organizador organizador) {
		System.out.print("Escribe un nombre: ");
		String nombre = sc.nextLine();
		System.out.print("Escribe una descripción: ");
		String desc = sc.nextLine();
		System.out.print("Escribe una fecha (AAAA-MM-DD): ");
		LocalDate fecha = LocalDate.parse(sc.nextLine());
		System.out.print("Escribe un hora (HH:MM): ");
		LocalTime hora = LocalTime.parse(sc.nextLine());
		System.out.print("Escribe un precio: ");
		double precio = Double.parseDouble(sc.nextLine());
		System.out.print("Escribe una ubicación: ");
		String ubicacion = sc.nextLine();
		
		System.out.print("Categoría: ");
		String nomCat = sc.nextLine();
		Categoria cat = categoriaDao.obtenerCategoria(nomCat);

		if (cat != null) {
			Evento nuevo = new Evento(nombre, desc, fecha, hora, precio, ubicacion, cat, organizador);
			if(eventoDao.insertarEvento(nuevo)) {
				System.out.println("Evento creado correctamente por " + organizador.getNombre());
			} else {
				System.out.println("Error: El nombre del evento ya existe.");
			}
		} else {
			System.out.println("Error: Categoría no válida.");
		}
	}
}