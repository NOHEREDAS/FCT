package servicio;

import java.util.Scanner;

import dominio.Categoria;
import persistencia.CategoriaDao;

public class CategoriaServicio implements ICategoriaServicio {
	private final Scanner sc;
	private CategoriaDao categoriaDao;
	
	public CategoriaServicio(Scanner sc) {
		this.sc = sc;
		this.categoriaDao = new CategoriaDao();
	}

	@Override
	public Categoria buscarCategoria() {
		// 1. Le pedimos al usuario el nombre de la categoria
		System.out.println("Escribe a continuacion el nombre de la categoria que deseas buscar:");
		String nombre = sc.nextLine();
		
		// 2. Usamos la funcion del dao para buscar el objeto
		Categoria categoriaEncontrada = categoriaDao.obtenerCategoria(nombre);
		
		// 3. Verificamos si existe y mostramos el resultado
		if (categoriaEncontrada != null) {
			System.out.println("Categoría encontrada: " + categoriaEncontrada.getNombre());
			System.out.println("Descripción: " + categoriaEncontrada.getDescripcion());
		} else {
			System.out.println("Error: No existe ninguna categoría con el nombre " + nombre);
		}
		
		return categoriaEncontrada;
	}
}