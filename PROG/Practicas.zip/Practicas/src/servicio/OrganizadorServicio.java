package servicio;

import java.util.Scanner;

import dominio.Organizador;
import persistencia.OrganizadorDao;

public class OrganizadorServicio implements IOrganizadorServicio {
	private final Scanner sc;
	private OrganizadorDao organizadorDao;

	public OrganizadorServicio(Scanner sc) {
		this.sc = sc;
		this.organizadorDao = new OrganizadorDao();
	}

	@Override
	public Organizador hacerLogin() {
		System.out.print("Introduce tu nombre de usuario: ");
		String nombre = sc.nextLine();
		
		System.out.print("Introduce tu contraseña: ");
		String contrasenia = sc.nextLine();

		// Llamamos al método login del DAO que ya comprueba nombre y contraseña
		Organizador organizador = organizadorDao.login(nombre, contrasenia);

		if (organizador != null) {
			System.out.println("Bienvenido " + organizador.getNombre());
			return organizador;
		} else {
			System.out.println("Error: Nombre de usuario o contraseña incorrectos.");
			return null;
		}
	}

	@Override
	public void registrarOrganizador() {
		System.out.print("Introduce un nombre: ");
		String nombre = sc.nextLine();
		
		System.out.print("Introduce un email: ");
		String email = sc.nextLine();
		
		System.out.print("Introduce una contraseña: ");
		String contrasenia = sc.nextLine();
		
		System.out.print("Introduce un telefono de contacto: ");
		String telefono = sc.nextLine();

		// Creamos el nuevo objeto Organizador
		Organizador nuevoOrg = new Organizador(nombre, email, contrasenia, telefono);

		// Intentamos registrarlo a través del DAO
		boolean exito = organizadorDao.registrar(nuevoOrg);

		if (exito) {
			System.out.println("Organizador registrado correctamente. Ya puedes iniciar sesión.");
		} else {
			System.out.println("Error: El nombre de organizador '" + nombre + "' ya está en uso.");
		}
	}
}