package servicio;

import java.util.Scanner;

import dominio.Usuario;
import persistencia.UsuarioDao;

public class UsuarioServicio implements IUsuarioServicio {
	private final Scanner sc;
	private UsuarioDao usuarioDao;
	
	public UsuarioServicio(Scanner sc) {
		this.sc = sc;
		this.usuarioDao = new UsuarioDao();
	}

	@Override
	public Usuario hacerLogin() {
		System.out.print("Introduce un nombre: ");
		String nombre = sc.nextLine();
		
		System.out.print("Introduce tu contraseña: ");
		String contrasenia = sc.nextLine();
		
		// Llamamos al método login del DAO
		Usuario usuario = usuarioDao.login(nombre, contrasenia);
		
		if (usuario != null) {
			System.out.println("¡Bienvenido " + usuario.getNombre() + "!");
			return usuario;
		} else {
			System.out.println("Error: El nombre o la contraseña son incorrectos.");
			return null;
		}
	}

	@Override
	public void registrarUsuario() {

		System.out.print("Introduce tu nombre: ");
		String nombre = sc.nextLine();
		
		System.out.print("Introduce tu email: ");
		String email = sc.nextLine();
		
		System.out.print("Introduce tu contraseña: ");
		String contrasenia = sc.nextLine();
		
		// Creamos el nuevo objeto Usuario
		Usuario nuevoUsuario = new Usuario(nombre, email, contrasenia);
		
		// Intentamos registrarlo en el DAO
		boolean registrado = usuarioDao.registrar(nuevoUsuario);
		
		if (registrado) {
			System.out.println("Usuario registrado con éxito. Ya puedes iniciar sesión.");
		} else {
			System.out.println("Error: El nombre de usuario ya está registrado.");
		}
	}
}